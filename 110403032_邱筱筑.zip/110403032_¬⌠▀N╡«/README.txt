demo.html是主要網頁
demo.js是script
mystyle.css是特效用
